package com.example.reporter_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
