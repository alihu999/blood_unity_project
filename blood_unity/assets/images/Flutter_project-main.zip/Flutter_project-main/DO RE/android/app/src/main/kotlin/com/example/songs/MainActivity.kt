package com.example.songs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
