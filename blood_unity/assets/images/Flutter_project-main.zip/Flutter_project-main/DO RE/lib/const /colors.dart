import 'package:flutter/material.dart';

class AppColors {
  static Color firstColor = const Color(0xff2B32B2);
  static Color secondColor = const Color(0xff1488cc);
}
