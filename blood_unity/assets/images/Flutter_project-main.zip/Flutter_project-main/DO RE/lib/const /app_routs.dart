class AppRoute {
  static String playSongs = "/playSongs";
}
