import 'package:flutter/widgets.dart';

class Account extends StatelessWidget {
  const Account({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Account"),
    );
  }
}
