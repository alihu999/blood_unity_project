class HomeImage {
  String imageUrl;
  String title;
  String weatherUrl;
  HomeImage(
      {required this.imageUrl, required this.title, required this.weatherUrl});
}
