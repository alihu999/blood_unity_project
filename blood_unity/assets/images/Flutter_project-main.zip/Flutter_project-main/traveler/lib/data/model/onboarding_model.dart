class OnBoardingModel {
  String urlImage;
  String title;
  String body;
  OnBoardingModel(
      {required this.urlImage, required this.title, required this.body});
}
