import 'package:flutter/material.dart';

class AppColor {
  static Color firstColor = const Color(0xff0f046c);
  static Color secondColor = const Color(0xffff776b);
  static Color thirdColor = const Color(0xff4546ec);
  static Color fourthColor = const Color(0xff91b3fa);
}
