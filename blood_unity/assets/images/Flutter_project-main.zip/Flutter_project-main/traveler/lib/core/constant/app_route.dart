class AppRoute {
  static String signIn = "/signIn";
  static String onBoarding = "/onBoarding";
  static String forgetPassword = "/forgetPassword";
  static String signUp = "/signUp";
  static String homePage = "/homePage";
  static String confirmPhone = "/confirmPassword";
  static String confirmPhoneForgetPassword = "/ConfirmPhoneForgetPassword";
  static String resetPassword = "/ResetPassword";
  static String detailsPage = "/detailsPage";
}
