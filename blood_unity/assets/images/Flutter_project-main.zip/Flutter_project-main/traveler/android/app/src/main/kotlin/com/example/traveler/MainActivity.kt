package com.example.traveler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
